<?php

namespace App\Filament\Resources\DinerResource\Pages;

use App\Filament\Resources\DinerResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDiner extends CreateRecord
{
    protected static string $resource = DinerResource::class;
}
