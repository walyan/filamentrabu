<?php

namespace App\Filament\Resources\BreakfastResource\Pages;

use App\Filament\Resources\BreakfastResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBreakfast extends CreateRecord
{
    protected static string $resource = BreakfastResource::class;
}
